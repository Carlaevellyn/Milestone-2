// Classe Usuario.java - Representa um usuário na plataforma
package br.ufal.ic.p2.jackut.models;

import java.io.Serializable;
import java.util.*;

public class Usuario implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String login;
    private final String senha;
    private final String nome;
    private final Perfil perfil;
    private final Set<Usuario> amigos = new LinkedHashSet<>();
    private final Set<Usuario> convitesEnviados = new LinkedHashSet<>();
    private final Set<Usuario> convitesRecebidos = new LinkedHashSet<>();
    private final Queue<String> recadosRecebidos = new LinkedList<>();
    private final Queue<String> mensagensRecebidas = new LinkedList<>();
    private final Set<Usuario> idolos = new HashSet<>();
    private final Set<Usuario> fas = new HashSet<>();
    private final Set<Usuario> paqueras = new HashSet<>();
    public final Set<Usuario> inimigos = new HashSet<>();
    private final Queue<String> recadosIdentificados = new LinkedList<>();
    private final Map<String, String> autoresRecados = new LinkedHashMap<>(); // Recado -> Autor

    // Construtor - Inicializa o usuário com login, senha e nome
    public Usuario(String login, String senha, String nome) {
        this.login = login;
        this.senha = senha;
        this.nome = nome;
        this.perfil = new Perfil();
    }

    public String getLogin() { return login; }
    public String getSenha() { return senha; }
    public String getNome() { return nome; }
    public Perfil getPerfil() { return perfil; }
    public Set<Usuario> getAmigos() { return new HashSet<>(amigos); }
    public Set<Usuario> getConvitesEnviados() { return new HashSet<>(convitesEnviados); }
    public Set<Usuario> getConvitesRecebidos() { return new HashSet<>(convitesRecebidos); }
    public Set<Usuario> getIdolos() { return new HashSet<>(idolos); }
    public Set<Usuario> getFas() { return new HashSet<>(fas); }
    public Set<Usuario> getPaqueras() { return new HashSet<>(paqueras); }
    public Queue<String> lerTodosRecados() { return new LinkedList<>(recadosRecebidos); }
    public Queue<String> lerTodosRecadosIdentificados() { return new LinkedList<>(recadosIdentificados); }

    public void enviarConvite(Usuario amigo) {
        if (!convitesEnviados.contains(amigo)) {
            convitesEnviados.add(amigo);
            amigo.receberConvite(this);
        }
    }

    public void receberConvite(Usuario amigo) {
        if (!convitesRecebidos.contains(amigo)) {
            convitesRecebidos.add(amigo);
        }
    }
    public void adicionarIdolo(Usuario idolo) {
        if (idolos.contains(idolo)) {
            throw new RuntimeException("Usuário já está adicionado como ídolo.");
        }
        idolos.add(idolo);
        idolo.fas.add(this);
    }

    public void adicionarPaquera(Usuario paquera) {
        if (paqueras.contains(paquera)) {
            throw new RuntimeException("Usuário já está adicionado como paquera.");
        }
        paqueras.add(paquera);

        // confirma se é mútuo
        if (paquera.paqueras.contains(this)) {
            String recado1 = paquera.getNome() + " é seu paquera - Recado do Jackut.";
            String recado2 = this.getNome() + " é seu paquera - Recado do Jackut.";

            // Modificado para usar a nova assinatura
            this.receberRecado(paquera.getLogin(), recado1);
            paquera.receberRecado(this.getLogin(), recado2);
        }
    }
    // New methods for enemy relationship
    public void adicionarInimigo(Usuario inimigo) {
        if (inimigos.contains(inimigo)) {
            throw new RuntimeException("Usuário já está adicionado como inimigo.");
        }
        inimigos.add(inimigo);
    }
    public void limparRecadosDoUsuario(String loginRemetente) {
        Queue<String> novosRecados = new LinkedList<>();
        for (String recado : recadosRecebidos) {
            if (!loginRemetente.equals(autoresRecados.get(recado))) {
                novosRecados.add(recado);
            }
        }
        recadosRecebidos.clear();
        recadosRecebidos.addAll(novosRecados);

        // Limpar o mapa de autores também
        autoresRecados.entrySet().removeIf(entry -> loginRemetente.equals(entry.getValue()));
    }

    public boolean aceitarConvite(Usuario amigo) {
        if (convitesRecebidos.remove(amigo)) {
            amigos.add(amigo);
            amigo.amigos.add(this);
            amigo.convitesEnviados.remove(this);
            return true;
        }
        return false;
    }
    public String lerRecado() {
        String recado = recadosRecebidos.poll();
        if (recado != null) {
            autoresRecados.remove(recado);
        }
        return recado;
    }

    public void limparRecadosIdentificados() { recadosIdentificados.clear(); }

    public void receberRecadoIdentificado(String recado) { recadosIdentificados.add(recado); }

    public void limparRecados() { recadosRecebidos.clear(); autoresRecados.clear(); }

    public boolean temConvitePendenteDe(Usuario usuario) { return convitesRecebidos.contains(usuario); }

    // Adiciona um amigo à lista de amigos do usuário
    public boolean temRecados() { return !recadosRecebidos.isEmpty(); }

    // Envia um recado para outro usuário
    public void receberRecado(String remetenteLogin, String recado) { recadosRecebidos.add(recado); autoresRecados.put(recado, remetenteLogin); }

    public void receberMensagem(String mensagem) { mensagensRecebidas.add(mensagem); }

    public boolean temMensagens() { return !mensagensRecebidas.isEmpty(); }

    public boolean ehFa(Usuario idolo) { return idolo.fas.contains(this);}

    public boolean ehPaquera(Usuario paquera) { return paqueras.contains(paquera); }

    public boolean ehInimigo(Usuario usuario) { return inimigos.contains(usuario); }

    public boolean isBlockedBy(Usuario usuario) { return usuario.inimigos.contains(this); }

    public String lerMensagem() { return mensagensRecebidas.poll(); }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Usuario other = (Usuario) obj;
        return login.equals(other.login);
    }

    @Override
    public int hashCode() {
        return login.hashCode();
    }
}

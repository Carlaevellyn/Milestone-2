package br.ufal.ic.p2.jackut.models;

import java.io.Serializable;
import java.util.LinkedHashSet;
import java.util.Set;

public class Comunidade implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String nome;
    private final String descricao;
    private final Usuario dono;
    private final Set<Usuario> membros;

    public Comunidade(String nome, String descricao, Usuario dono) {
        this.nome = nome;
        this.descricao = descricao;
        this.dono = dono;
        this.membros = new LinkedHashSet<>();
        this.membros.add(dono);
    }

    public String getNome() {
        return nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public Usuario getDono() {
        return dono;
    }

    public Set<Usuario> getMembros() {
        return new LinkedHashSet<>(membros);
    }

    public void adicionarMembro(Usuario usuario) {
        if (!membros.add(usuario)) {
            throw new RuntimeException("Usuario já faz parte dessa comunidade.");
        }
    }
}